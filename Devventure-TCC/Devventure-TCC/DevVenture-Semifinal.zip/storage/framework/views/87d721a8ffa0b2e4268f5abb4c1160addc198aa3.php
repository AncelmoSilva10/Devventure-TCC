<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Enviar Aviso</title>
    
    <link href="<?php echo e(asset('css/Professor/avisos.css')); ?>" rel="stylesheet"> 
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main>
    <section class="form-container">
        
        <a href="<?php echo e(url()->previous()); ?>" class="btn-voltar">
            <i class='bx bx-chevron-left'></i>
            Voltar
        </a>
        <h1>Enviar Novo Aviso</h1>
        <p>Escreva a mensagem e selecione para quais turmas deseja enviar.</p>

        <form action="<?php echo e(route('professor.avisos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="titulo">Título</label>
                <input type="text" id="titulo" name="titulo" placeholder="Ex: Lembrete sobre a prova" required value="<?php echo e(old('titulo')); ?>">
                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="conteudo">Conteúdo do Aviso</label>
                <textarea id="conteudo" name="conteudo" rows="8" placeholder="Digite a mensagem completa aqui..." required><?php echo e(old('conteudo')); ?></textarea>
                <?php $__errorArgs = ['conteudo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <h3>Enviar para as turmas:</h3>
                <div class="turmas-checkbox-grid">
                    <?php $__empty_1 = true; $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="checkbox-item">
                            <input type="checkbox" id="turma_<?php echo e($turma->id); ?>" name="turmas[]" value="<?php echo e($turma->id); ?>">
                            <label for="turma_<?php echo e($turma->id); ?>"><?php echo e($turma->nome_turma); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Você não possui turmas para enviar avisos.</p>
                    <?php endif; ?>
                </div>
                <?php $__errorArgs = ['turmas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error-message"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn-enviar">Enviar Aviso</button>

        </form>
    </section>
</main>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH /Users/Vini/ws_development~/Devventure-TCC/Devventure-TCC/Devventure-TCC/resources/views/professor/avisosCriar.blade.php ENDPATH**/ ?>